<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width" />
  <title>cruds</title>
  <link rel="stylesheet" href="style .css" />
</head>
<body>
<ul class="back">
<div class="head"><img src="pubg.png">
<h4 class="appname">pubg mobile</h4>
<p class="appbundle">com.tencent.ig</p></div>

<div class="dnum"><p class="pdnum">دابەزاندنەکان</p>
<p class="pnumber">29</p></div>
<div class="size"><p class="psize">قەبارە</p>
<p class="pnumber">1.89mb</p></div>
<div class="virsion"><p class="pvirsion">ڤێرژن</p>
<p class="pnumber">2.0.0</p></div>


<div class="discription">
<p class="appdis"> :تایبەت مەندی ئاپکەکە</p>

</div>

<div class="download">
<a class="button1">دابەزاندن<a>
 </div>


</ul>
 

  <script src="script.js"></script>
</body>
</html>